package k8s.no_root

import data.k8s.no_root.deny
