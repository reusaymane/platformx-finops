package k8s.resource_limits

import data.k8s.resource_limits.deny
