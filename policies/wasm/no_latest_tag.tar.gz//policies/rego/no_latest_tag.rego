package k8s.no_latest_tag

import data.k8s.no_latest_tag.deny
